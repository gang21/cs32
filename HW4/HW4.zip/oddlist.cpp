//void removeOdd(list<int>& li) {
//    if (li.empty())
//        return;
//    list<int>::iterator it = li.begin();
//    while (it != li.end()) {
//        if (((*it)%2) == 1) {
//            li.erase(it);
//        }
//        it++;
//    }
//}
